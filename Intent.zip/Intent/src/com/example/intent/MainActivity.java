package com.example.intent;

import java.util.ArrayList;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class MainActivity extends Activity {

	ListView lv;
	ArrayList<Contact> list=new ArrayList<Contact>();
	ItemAdapter adapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        this.lv=(ListView) this.findViewById(R.id.listView1);
        this.adapter=new ItemAdapter(this,list);
        this.lv.setAdapter(adapter);
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		Intent intent = new Intent(this, ManejaActivity.class);
		this.startActivityForResult(intent,0);
		
		return super.onOptionsItemSelected(item);
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode==Activity.RESULT_OK){
			if(requestCode==0){
				
				Bundle b=data.getExtras();
				Uri image = b.getParcelable("image");
				String name = b.getString("name");
				String tel = b.getString("tel");
				
				Contact contact = new Contact(image,name,tel);
				list.add(contact);
				adapter.notifyDataSetChanged();
				
			}
			
		}
		
	}
    
    
    
}
